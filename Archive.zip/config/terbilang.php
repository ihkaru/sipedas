<?php
return ['locale'=> 'id'];
