<?php

namespace App\Models;

use App\Supports\Constants;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class Pegawai extends Model {
    use HasFactory;
    protected $guarded = [];
    protected $primaryKey = "nip";

    protected function casts(): array {
        return [
            'nip' => 'string',
        ];
    }

    public function user() {
        return $this->hasOne(User::class, "email", "email");
    }

    public function penugasans() {
        return $this->hasMany(Penugasan::class, "nip", "nip");
    }

    public function atasanLangsung() {
        return $this->hasOne(Pegawai::class, "nip", "atasan_langsung_id");
    }
    protected function pangkatGolongan(): Attribute {
        return Attribute::make(
            get: function (mixed $value, array $attributes) {
                // Jika Pegawai Golongan V maka langsung tampilkan nama jabatan saja.
                if ($attributes['golongan'] == 'V') {
                    return Constants::PANGKAT_OPTIONS[$attributes['golongan']];
                }
                $golongan = $attributes['pangkat'] == Constants::PANGKAT_IV ? Constants::GOLONGAN_IV_OPTIONS[$attributes['golongan']] : Constants::GOLONGAN_I_III_OPTIONS[$attributes['golongan']];
                $res = Constants::PANGKAT_OPTIONS[$attributes['pangkat']] . ' ' . ($golongan ? '' . $golongan . ' ' : '') . "(" . strtoupper($attributes['pangkat']) . "/" . $attributes['golongan'] . ")";
                return $res;
            },
        );
    }

    public static function getPpkByDate($date = null) {
        if (!$date) {
            $date = now();
        }

        // Transition date: 2026-04-01
        // New PPK starting April 2026: Budiman Aller Silaban (NIP: 200001062023021001)
        if (Carbon::parse($date)->greaterThanOrEqualTo('2026-04-01')) {
            return self::find("200001062023021001");
        }

        // Before transition, use the setting
        $nipDefault = Pengaturan::key("NIP_PPK_SATER")->nilai ?? '199306062016021001';
        return self::find($nipDefault);
    }
}
