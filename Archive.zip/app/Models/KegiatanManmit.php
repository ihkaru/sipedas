<?php

namespace App\Models;

use App\Supports\Constants;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Support\Str;

class KegiatanManmit extends Model
{
    use HasFactory;

    public $incrementing = false;
    protected $keyType = 'string';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'nama',
        'tgl_mulai_pelaksanaan',
        'tgl_akhir_pelaksanaan',
        'tgl_mulai_penawaran',   // Ini yang akan kita gunakan
        'tgl_akhir_penawaran',    // Ini yang akan kita gunakan
        'jenis_kegiatan',
        'frekuensi_kegiatan',
    ];



    public static function importKegiatanManmit($data)
    {
        $res = [];
        $res['id'] = $data['id_kegiatan_manmit'];
        $res['nama'] = $data['nama_kegiatan_manmit'];
        $res['tgl_mulai_pelaksanaan'] = $data['tanggal_mulai_pelaksanaan'] ?? null;
        $res['tgl_akhir_pelaksanaan'] = $data['tanggal_akhir_pelaksanaan'] ?? null;
        $res['tgl_mulai_penawaran'] = $data['tanggal_mulai_penawaran'] ?? null;
        $res['tgl_akhir_penawaran'] = $data['tanggal_akhir_penawaran'] ?? null;
        return new KegiatanManmit($res);
    }
    public function kegiatans()
    {
        return $this->hasMany(Kegiatan::class);
    }
    protected function idNama(): Attribute
    {
        return Attribute::make(
            get: fn(mixed $value, array $attributes) => "(" . $attributes["id"] . ")" . " " . $attributes["nama"],
        );
    }
    public static function getSelectOptions()
    {
        return self::pluck('nama', 'id')->map(fn($v, $k) => "($k) " . $v);
    }

    public function honors(): HasMany
    {
        return $this->hasMany(Honor::class);
    }
    public function alokasiHonors(): HasManyThrough
    {
        return $this->hasManyThrough(AlokasiHonor::class, Honor::class, 'kegiatan_manmit_id', 'honor_id', 'id', 'id');
    }
}
